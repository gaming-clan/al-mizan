---
name: Al-Mizan Night
colors:
  surface: '#131313'
  surface-dim: '#131313'
  surface-bright: '#3a3939'
  surface-container-lowest: '#0e0e0e'
  surface-container-low: '#1c1b1b'
  surface-container: '#201f1f'
  surface-container-high: '#2a2a2a'
  surface-container-highest: '#353534'
  on-surface: '#e5e2e1'
  on-surface-variant: '#bbcabf'
  inverse-surface: '#e5e2e1'
  inverse-on-surface: '#313030'
  outline: '#86948a'
  outline-variant: '#3c4a42'
  surface-tint: '#4edea3'
  primary: '#4edea3'
  on-primary: '#003824'
  primary-container: '#10b981'
  on-primary-container: '#00422b'
  inverse-primary: '#006c49'
  secondary: '#e9c349'
  on-secondary: '#3c2f00'
  secondary-container: '#af8d11'
  on-secondary-container: '#342800'
  tertiary: '#c9c7ba'
  on-tertiary: '#313128'
  tertiary-container: '#a5a397'
  on-tertiary-container: '#3a3a30'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#6ffbbe'
  primary-fixed-dim: '#4edea3'
  on-primary-fixed: '#002113'
  on-primary-fixed-variant: '#005236'
  secondary-fixed: '#ffe088'
  secondary-fixed-dim: '#e9c349'
  on-secondary-fixed: '#241a00'
  on-secondary-fixed-variant: '#574500'
  tertiary-fixed: '#e5e3d5'
  tertiary-fixed-dim: '#c9c7ba'
  on-tertiary-fixed: '#1c1c14'
  on-tertiary-fixed-variant: '#48473d'
  background: '#131313'
  on-background: '#e5e2e1'
  surface-variant: '#353534'
typography:
  headline-xl:
    fontFamily: Source Serif 4
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 56px
    letterSpacing: -0.02em
  headline-xl-mobile:
    fontFamily: Source Serif 4
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
  headline-lg:
    fontFamily: Source Serif 4
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
  headline-md:
    fontFamily: Source Serif 4
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  body-lg:
    fontFamily: Source Serif 4
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 30px
  body-md:
    fontFamily: Source Serif 4
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 26px
  label-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 20px
    letterSpacing: 0.05em
  label-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.08em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  unit: 4px
  gutter: 24px
  margin-desktop: 64px
  margin-mobile: 20px
  container-max: 1120px
---

## Brand & Style

The design system is a sophisticated, dark-mode adaptation of a scholarly and judicial aesthetic. It is tailored for deep focus, long-form reading, and academic rigor in low-light environments. The personality is authoritative yet tranquil, evoking the atmosphere of a private, moonlit library.

The design style blends **Minimalism** with **Tonal Layering**. It avoids harsh light-emitting surfaces, instead using deep obsidian depths contrasted with parchment-tinted accents. The visual language emphasizes balance, clarity, and intellectual heritage through high-quality serif typography and precise, understated borders.

## Colors

The palette is anchored in a deep obsidian base to minimize eye strain. The primary brand color, a classic emerald, is shifted toward a more vibrant, luminous green (#10b981) to ensure WCAG AA compliance and legibility against the dark background. 

Secondary accents use a subdued gold to denote premium features or high-level navigation. Tertiary surfaces utilize a "parchment-night" tint—a very dark, warm-grey—to create subtle container separation without breaking the dark-mode immersion. Primary text uses an off-white to prevent the "halation" effect of pure white on black.

## Typography

This design system relies heavily on **Source Serif 4** to convey a literary and authoritative tone. To maintain a modern edge and ensure functional clarity, **Inter** is utilized for functional labels, metadata, and UI controls.

Large headlines feature tight letter spacing and heavier weights for a commanding presence. Body text is prioritized for legibility with a generous line-height (1.6x) to facilitate comfortable reading of dense scholarly texts. Labels are rendered in all-caps with increased letter spacing to provide a clear visual departure from the serif-heavy content.

## Layout & Spacing

The design system employs a **Fixed Grid** philosophy for desktop to evoke the structured feel of a printed manuscript. Content is centered within a 1120px container to keep line lengths optimal for reading. 

The rhythm is based on a 4px baseline, with vertical rhythm emphasizing breathing room between sections (using 48px or 64px gaps). On mobile, the grid transitions to a fluid model with 20px side margins, ensuring text remains the focal point while UI elements are pulled to the edges for thumb-accessibility.

## Elevation & Depth

Depth is achieved through **Tonal Layering** rather than heavy shadows. In this dark environment:
- **Level 0 (Base):** #0a0a0a (Deepest obsidian).
- **Level 1 (Cards/Containers):** #121212 with a 1px border of #2d2d24.
- **Level 2 (Modals/Overlays):** #1c1c1c with a soft, 20% opacity gold-tinted glow (40px blur, 0px offset).

Outlines are preferred over shadows to define structure. When shadows are used, they are "Ambient Shadows"—extremely diffused, low-opacity, and slightly tinted with the primary emerald or secondary gold color to suggest a soft light source hitting the surface.

## Shapes

The shape language is **Soft** and restrained. Large radius curves are avoided to prevent the UI from appearing too "bubbly" or casual. A standard 4px radius (`0.25rem`) is applied to buttons, input fields, and small containers. For larger featured cards or modal windows, a maximum radius of 12px is used to maintain a structured, professional appearance that feels established and stable.

## Components

### Buttons
- **Primary:** Solid Emerald (#10b981) with black text. High contrast for critical actions.
- **Secondary:** Outlined with Gold (#d4af37), using gold text. 1px border width.
- **Tertiary:** Ghost style, using the off-white text and a subtle parchment-tint hover state.

### Input Fields
Inputs are dark (#121212) with a 1px bottom border only in its default state, transitioning to a full emerald frame on focus. This mimics the underlined aesthetic of traditional annotations.

### Cards
Cards use a subtle gradient—from the tertiary color at the top-left to the base color at the bottom-right—to create a sense of physical thickness. Borders are essential here for separation.

### Lists & Dividers
Dividers should be low-contrast (#2d2d24). Lists should feature generous vertical padding (12px-16px) to maintain the "scholarly" airy feel.

### Additional Components
- **The Gloss:** A specialized tooltip or side-panel component for citations and definitions, using a parchment-tinted background with serif-italic text.
- **The Scale:** A custom slider/toggle control using the primary emerald color to indicate balance or weighted metrics.