---
name: Desert Sands
colors:
  surface: '#fff8f0'
  surface-dim: '#e2d9c8'
  surface-bright: '#fff8f0'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#fcf3e1'
  surface-container: '#f6eddb'
  surface-container-high: '#f0e7d5'
  surface-container-highest: '#eae2d0'
  on-surface: '#1f1b10'
  on-surface-variant: '#55433b'
  inverse-surface: '#343024'
  inverse-on-surface: '#f9f0de'
  outline: '#88736a'
  outline-variant: '#dbc1b7'
  surface-tint: '#97481f'
  primary: '#94451d'
  on-primary: '#ffffff'
  primary-container: '#b35d33'
  on-primary-container: '#fffcff'
  inverse-primary: '#ffb595'
  secondary: '#7d562d'
  on-secondary: '#ffffff'
  secondary-container: '#ffca98'
  on-secondary-container: '#7a532a'
  tertiary: '#6e5847'
  on-tertiary: '#ffffff'
  tertiary-container: '#88705e'
  on-tertiary-container: '#fffcff'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ffdbcc'
  primary-fixed-dim: '#ffb595'
  on-primary-fixed: '#351000'
  on-primary-fixed-variant: '#793109'
  secondary-fixed: '#ffdcbd'
  secondary-fixed-dim: '#f0bd8b'
  on-secondary-fixed: '#2c1600'
  on-secondary-fixed-variant: '#623f18'
  tertiary-fixed: '#fbddc7'
  tertiary-fixed-dim: '#dec1ac'
  on-tertiary-fixed: '#28180b'
  on-tertiary-fixed-variant: '#574333'
  background: '#fff8f0'
  on-background: '#1f1b10'
  surface-variant: '#eae2d0'
typography:
  display-lg:
    fontFamily: Source Serif 4
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 56px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Source Serif 4
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
  headline-lg-mobile:
    fontFamily: Source Serif 4
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 36px
  title-md:
    fontFamily: Source Serif 4
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  body-lg:
    fontFamily: Source Serif 4
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 30px
  body-md:
    fontFamily: Source Serif 4
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 26px
  label-sm:
    fontFamily: Source Serif 4
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.05em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  unit: 8px
  container-max: 1200px
  gutter: 24px
  margin-mobile: 16px
  margin-desktop: 48px
  section-gap: 64px
---

## Brand & Style
The design system for this application is built upon a foundation of scholarly authority and the enduring stillness of the desert. It targets a serious audience seeking religious and legal clarity (Fiqh), requiring a UI that feels like an inherited heirloom—weighty, intentional, and timeless.

The aesthetic blends **Minimalism** with **Tactile/Skeuomorphic** elements. While the layouts remain clean and functional to support deep reading, the surfaces utilize subtle textures of aged parchment and micro-patterns inspired by traditional geometric bookbinding. The emotional goal is to evoke a sense of "digital sanctuary," where the user feels grounded in tradition yet supported by modern clarity.

## Colors
The palette is derived from the natural materials of the Levant and the Hejaz. 
- **Primary (Deep Terracotta):** Used for primary actions, active states, and structural highlights. It represents the warmth of sun-baked earth.
- **Secondary (Warm Ochre):** Used for accents, secondary buttons, and decorative icons.
- **Tertiary (Deep Umber/Clay):** Used for high-contrast text and borders to ensure legibility without the harshness of pure black.
- **Neutral (Aged Parchment):** The primary background color. It reduces eye strain during long reading sessions compared to pure white.
- **Background Tints:** Use a slightly lighter `parchment_light` for main content areas and the standard `neutral` for sidebars and navigation to create subtle environmental depth.

## Typography
Source Serif 4 is the sole typeface, providing a unified, authoritative voice reminiscent of printed academic journals. 
- **Hierarchy:** Use the semi-bold and bold weights sparingly for headers to maintain a sophisticated editorial feel. 
- **Legibility:** Body text uses a generous line height (1.6x) to accommodate the intricate details of serif characters on parchment-colored backgrounds.
- **Labels:** Small labels use an increased letter spacing and uppercase styling to distinguish functional metadata from narrative content.
- **Arabic Script:** When paired with Arabic text, ensure the typeface used has a matching optical weight to Source Serif 4 (such as Amiri or Noto Naskh Arabic) to maintain the scholarly aesthetic.

## Layout & Spacing
The layout follows a **Fixed Grid** philosophy on desktop to mimic the centered, justified blocks of traditional manuscript pages. On mobile, it transitions to a fluid single-column layout with generous side margins to allow the content to breathe.

- **The Manuscript Column:** Main reading content should be constrained to a maximum width of 720px regardless of screen size to ensure optimal line lengths for reading.
- **Rhythm:** A strict 8px baseline grid is used. Sections are separated by large vertical gaps to denote thematic shifts in the text.
- **Asymmetry:** Occasional right-aligned marginalia or pull-quotes can be used on desktop to mimic scholarly notations.

## Elevation & Depth
Depth is achieved through **Tonal Layers** and texture rather than drop shadows.
- **Surface Tiering:** The base layer is the "Parchment." Higher-level elements (like modals or cards) are rendered in a slightly lighter tint with a very fine 1px border in a "Clay" color.
- **Micro-Shadows:** If depth is required for buttons, use a single, sharp 1px offset shadow in a darker terracotta shade to simulate an embossed or stamped effect, rather than a soft ambient blur.
- **Textures:** Apply a subtle noise texture (3-5% opacity) over the entire background to simulate the grain of aged paper. Use geometric dividers—thin lines with a center diamond or star—to separate sections.

## Shapes
This design system utilizes **Soft** geometry. While the atmosphere is traditional, sharp corners can feel too aggressive for a spiritual app. 
- **Corner Radius:** A consistent 0.25rem (4px) radius is applied to cards and inputs, providing just enough softness to feel approachable while maintaining a structured, formal appearance.
- **Decorative Elements:** Use 45-degree angled corners or "clipped" corners for special decorative containers (like featured quotes) to reference Islamic architectural motifs.

## Components
- **Buttons:** Primary buttons are filled with Deep Terracotta with centered white or cream text. Use a 1px inner stroke to give a "stamped" appearance. Secondary buttons use the Clay color for outlines.
- **Cards:** Cards should have no shadow; instead, use a 1px border in a slightly darker parchment shade and a subtle background shift.
- **Lists:** Use custom bullet points, such as a small geometric star or a terracotta square, to reinforce the desert-manuscript theme.
- **Input Fields:** Use a "bottom-border only" style for text inputs to keep the UI light, using the Clay color for the underline. Labels should sit prominently above the field in `label-sm` style.
- **The "Fiqh" Chip:** Small, rounded-sm tags used for categories. These should use a Tertiary Umber background with Cream text to look like wax seals or leather tabs.
- **Dividers:** Instead of simple lines, use "Horoof" style dividers—a horizontal line that features a small geometric or calligraphic ornament in the center.