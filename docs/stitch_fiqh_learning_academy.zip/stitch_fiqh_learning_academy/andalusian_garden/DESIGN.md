---
name: Andalusian Garden
colors:
  surface: '#f8faf6'
  surface-dim: '#d8dbd7'
  surface-bright: '#f8faf6'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f4f1'
  surface-container: '#eceeeb'
  surface-container-high: '#e7e9e5'
  surface-container-highest: '#e1e3e0'
  on-surface: '#191c1b'
  on-surface-variant: '#404944'
  inverse-surface: '#2e312f'
  inverse-on-surface: '#eff1ee'
  outline: '#707974'
  outline-variant: '#bfc9c3'
  surface-tint: '#2b6954'
  primary: '#003527'
  on-primary: '#ffffff'
  primary-container: '#064e3b'
  on-primary-container: '#80bea6'
  inverse-primary: '#95d3ba'
  secondary: '#8f4953'
  on-secondary: '#ffffff'
  secondary-container: '#ffa6b1'
  on-secondary-container: '#7a3842'
  tertiary: '#2d2e2c'
  on-tertiary: '#ffffff'
  tertiary-container: '#444442'
  on-tertiary-container: '#b2b1ae'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#b0f0d6'
  primary-fixed-dim: '#95d3ba'
  on-primary-fixed: '#002117'
  on-primary-fixed-variant: '#0b513d'
  secondary-fixed: '#ffd9dc'
  secondary-fixed-dim: '#ffb2bb'
  on-secondary-fixed: '#3b0613'
  on-secondary-fixed-variant: '#73323d'
  tertiary-fixed: '#e4e2de'
  tertiary-fixed-dim: '#c8c6c3'
  on-tertiary-fixed: '#1b1c1a'
  on-tertiary-fixed-variant: '#474744'
  background: '#f8faf6'
  on-background: '#191c1b'
  surface-variant: '#e1e3e0'
typography:
  display-lg:
    fontFamily: Source Serif 4
    fontSize: 56px
    fontWeight: '700'
    lineHeight: 64px
    letterSpacing: -0.02em
  display-lg-mobile:
    fontFamily: Source Serif 4
    fontSize: 40px
    fontWeight: '700'
    lineHeight: 48px
    letterSpacing: -0.01em
  headline-lg:
    fontFamily: Source Serif 4
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
  headline-lg-mobile:
    fontFamily: Source Serif 4
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 36px
  headline-md:
    fontFamily: Source Serif 4
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  body-lg:
    fontFamily: Source Serif 4
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Source Serif 4
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  label-md:
    fontFamily: Source Serif 4
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.05em
  caption:
    fontFamily: Source Serif 4
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  unit: 4px
  xs: 4px
  sm: 8px
  md: 16px
  lg: 24px
  xl: 40px
  xxl: 64px
  container-max: 1280px
  gutter: 24px
---

## Brand & Style
The design system draws inspiration from the *Generalife* and the courtyards of the Alhambra, aiming to evoke a sense of "Al-Andalus" serenity. The brand personality is scholarly yet organic, blending historical academic rigor with the refreshing vitality of a botanical sanctuary. It targets an audience that appreciates quiet luxury, cultural depth, and meticulous craftsmanship.

The visual style is **Contemporary Organic**. It moves away from sterile modernism by introducing floral arabesque motifs, subtle botanical textures, and a soft, paper-like tactile quality. The emotional response should be one of "refreshment"—the digital equivalent of stepping into a shaded garden on a hot afternoon.

## Colors
The palette is built upon the contrast between deep vegetation and delicate flora.

- **Primary (Forest Green):** Used for primary actions, navigation headers, and high-level structural elements. It provides the grounding "shade" of the garden.
- **Secondary (Soft Rose):** Reserved for highlights, notifications, and soft calls-to-action. It represents the blooming flora.
- **Tertiary (Ivory):** The foundational surface color. It is warmer than pure white, reducing eye strain and mimicking aged parchment or sun-bleached stone.
- **Functional Neutrals:** A range of warm grays derived from the Primary Green to maintain tonal harmony across text and borders.

## Typography
This design system utilizes **Source Serif 4** exclusively to maintain a literary, authoritative, and timeless aesthetic. The high x-height and elegant serifs ensure legibility while reinforcing the "Spanish Scholar" vibe.

- **Headlines:** Use a tighter letter-spacing and higher weights to create visual impact.
- **Body Text:** Generous line-height is mandatory to evoke the spaciousness of a garden courtyard.
- **Labels:** Set in SemiBold with increased letter-spacing and uppercase styling for a classic, architectural feel on buttons and small headers.

## Layout & Spacing
The layout follows a **Fluid-Fixed Hybrid** model. Content is contained within a 1280px max-width container on desktop, centered with significant "breathing room" margins.

- **Grid:** A 12-column grid is used for desktop, 8-column for tablet, and 4-column for mobile.
- **Rhythm:** Spacing follows a 4px baseline, but primary content blocks should favor `lg (24px)` and `xl (40px)` increments to avoid visual clutter.
- **Reflow:** On mobile, horizontal padding should never drop below 20px to maintain the feeling of an "enclosed sanctuary."

## Elevation & Depth
In this design system, depth is achieved through **Tonal Layering** and **Soft Ambient Shadows** rather than stark borders.

- **The Ground:** The base layer is Ivory (#fdfbf7).
- **Elevated Surfaces:** Cards and modals use a pure white background with a very soft, diffused shadow tinted with Primary Green (e.g., `rgba(6, 78, 59, 0.04)`).
- **Interactive Depth:** Hover states involve a slight upward shift and a soft increase in shadow spread, mimicking an object being lifted toward a light source.
- **The "Mosaic" Layer:** Secondary structural elements (sidebars, footers) use a slightly darker ivory or a very pale tint of the forest green to create a recessed effect.

## Shapes
The shape language is defined by "The Arch." All corners are rounded to soften the interface, avoiding the harshness of traditional corporate tools.

- **Standard Elements:** Buttons and input fields use a 0.5rem radius.
- **Large Elements:** Cards and containers use a 1.5rem radius to evoke the arched doorways of Andalusian architecture.
- **Decorative Elements:** Use circular or "squircle" masks for avatars and icons. Floral arabesque patterns should be used as subtle background overlays with 5-10% opacity.

## Components
- **Buttons:** Primary buttons are Solid Forest Green with Ivory text. Secondary buttons are Soft Rose with Forest Green text. Tertiary buttons are transparent with underlined text. All buttons feature a 0.5rem radius.
- **Input Fields:** Use an Ivory-tinted background with a thin Forest Green bottom border (2px) that expands on focus. Labels are always floating or placed above the field in Label-MD style.
- **Cards:** Cards are pure white with a 1.5rem radius and a soft green-tinted shadow. They should include a subtle floral motif in the corner for high-priority items.
- **Chips:** Small, pill-shaped indicators using the Soft Rose background and Forest Green text for categories or tags.
- **Navigation:** The top navigation should be minimal, utilizing the Forest Green for the logo and primary links, with a Soft Rose underline for the active state.
- **Lists:** Separated by thin, low-opacity Forest Green dividers. Each list item should have a generous 16px padding to maintain the "airy" feel of the system.