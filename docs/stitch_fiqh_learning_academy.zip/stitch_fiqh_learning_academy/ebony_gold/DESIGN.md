---
name: Ebony & Gold
colors:
  surface: '#131313'
  surface-dim: '#131313'
  surface-bright: '#393939'
  surface-container-lowest: '#0e0e0e'
  surface-container-low: '#1c1b1b'
  surface-container: '#201f1f'
  surface-container-high: '#2a2a2a'
  surface-container-highest: '#353534'
  on-surface: '#e5e2e1'
  on-surface-variant: '#d0c5af'
  inverse-surface: '#e5e2e1'
  inverse-on-surface: '#313030'
  outline: '#99907c'
  outline-variant: '#4d4635'
  surface-tint: '#e9c349'
  primary: '#f2ca50'
  on-primary: '#3c2f00'
  primary-container: '#d4af37'
  on-primary-container: '#554300'
  inverse-primary: '#735c00'
  secondary: '#e8c263'
  on-secondary: '#3e2e00'
  secondary-container: '#7c5f01'
  on-secondary-container: '#ffdd89'
  tertiary: '#e2cd85'
  on-tertiary: '#3a3000'
  tertiary-container: '#c5b26d'
  on-tertiary-container: '#514408'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#ffe088'
  primary-fixed-dim: '#e9c349'
  on-primary-fixed: '#241a00'
  on-primary-fixed-variant: '#574500'
  secondary-fixed: '#ffdf93'
  secondary-fixed-dim: '#e8c263'
  on-secondary-fixed: '#241a00'
  on-secondary-fixed-variant: '#594400'
  tertiary-fixed: '#f7e298'
  tertiary-fixed-dim: '#dac67e'
  on-tertiary-fixed: '#221b00'
  on-tertiary-fixed-variant: '#53460a'
  background: '#131313'
  on-background: '#e5e2e1'
  surface-variant: '#353534'
typography:
  display-lg:
    fontFamily: Source Serif 4
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 56px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Source Serif 4
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
  headline-lg-mobile:
    fontFamily: Source Serif 4
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 36px
  title-md:
    fontFamily: Source Serif 4
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  body-lg:
    fontFamily: Source Serif 4
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 32px
  body-md:
    fontFamily: Source Serif 4
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 28px
  label-md:
    fontFamily: Source Serif 4
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.05em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  base: 8px
  container-padding: 24px
  gutter: 20px
  margin-mobile: 16px
  margin-desktop: 64px
---

## Brand & Style
This design system is crafted for a scholarly Fiqh application, evoking the reverence and weight of a gold-leafed manuscript. The personality is authoritative, timeless, and prestigious. By utilizing a high-contrast dark mode palette, the UI creates a focused, "night-reading" environment that mimics the physical experience of studying ancient texts under candlelight.

The aesthetic leans into **Luxury Minimalism** with a **Tactile** edge. It avoids modern trends like glassmorphism in favor of solid, structured layers and sharp, intentional highlights. The emotional response is one of deep respect, intellectual rigor, and spiritual calm.

## Colors
The palette is centered on the contrast between deep shadows and metallic light.
- **Primary (#D4AF37):** A prestigious gold used for primary actions, active states, and scholarly emphasis.
- **Secondary (#997A21):** A burnished gold for hover states and secondary icons to maintain hierarchy.
- **Tertiary (#F4DF95):** A pale champagne gold used for subtle highlights or high-legibility text on dark backgrounds.
- **Background (#121212):** A rich charcoal that serves as the base "void," reducing eye strain during long periods of study.
- **Surface (#1A1A1A):** Deep ebony for cards and containers, providing just enough elevation to separate content sections.

## Typography
The system uses **Source Serif 4** exclusively to maintain a scholarly, authoritative tone across all interfaces. 
- **Display and Headlines:** Use semi-bold weights with tight tracking to mimic the appearance of printed titles in a classical codex.
- **Body Text:** Optimized for long-form reading with a generous line height (1.75x) to ensure the intricate serifs are legible against the dark background.
- **Labels:** Small caps or uppercase transformations should be used for metadata and category labels to differentiate them from the narrative text without introducing a secondary font family.

## Layout & Spacing
The layout follows a **Fixed Grid** philosophy to create a sense of stability and permanence. 
- **Desktop:** A 12-column centered grid with wide margins (64px) to create an "open book" feel.
- **Mobile:** A 4-column grid with 16px margins. 
- **Spacing Rhythm:** Use an 8px base unit. Vertical rhythm is critical; maintain consistent 32px or 48px gaps between major sections of text to allow the content to breathe, reflecting the spacious margins of traditional illuminated manuscripts.

## Elevation & Depth
In this design system, depth is achieved through **Tonal Layering** and **Gold Accents** rather than traditional shadows.
- **Level 0 (Base):** #121212 (The background).
- **Level 1 (Containers):** #1A1A1A (Cards, navigation bars).
- **Level 2 (Popovers):** #242424 with a 1px solid border of #D4AF37 at 20% opacity.
- **Interactive Depth:** Use a subtle interior gold glow (inner shadow) for pressed states to simulate the indenting of a physical page. Avoid large ambient shadows to keep the design feeling grounded and "heavy."

## Shapes
The shape language is **Soft (0.25rem)**. While modern apps often use high roundedness, this system uses subtle corner radii to maintain a structural, architectural feel reminiscent of leather-bound book covers. 
- **Buttons and Inputs:** Use the standard 4px radius.
- **Featured Cards:** May use the `rounded-lg` (8px) setting to provide a softer focus on specific scholarly insights or daily ayats.

## Components
- **Buttons:** Primary buttons use a solid #D4AF37 fill with #121212 text. Secondary buttons use a ghost style with a #D4AF37 border and gold text.
- **Cards:** Ebony surfaces with a subtle top-border (2px) in Gold to denote importance or category.
- **Input Fields:** Darker than the container background (#121212) with a 1px border that illuminates to Gold on focus.
- **Lists:** Scholarly references should be separated by thin, low-opacity gold dividers (#D4AF37 at 15% opacity).
- **Chips:** Used for tag-based navigation (e.g., "Hanafi," "Maliki"), using a subtle gold outline and serif label.
- **Drop Caps:** For the start of major chapters or rulings, use an oversized, primary gold initial to emphasize the manuscript aesthetic.