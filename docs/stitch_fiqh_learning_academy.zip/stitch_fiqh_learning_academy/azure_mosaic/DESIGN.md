---
name: Azure Mosaic
colors:
  surface: '#f7f9fb'
  surface-dim: '#d8dadc'
  surface-bright: '#f7f9fb'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f4f6'
  surface-container: '#eceef0'
  surface-container-high: '#e6e8ea'
  surface-container-highest: '#e0e3e5'
  on-surface: '#191c1e'
  on-surface-variant: '#45474c'
  inverse-surface: '#2d3133'
  inverse-on-surface: '#eff1f3'
  outline: '#75777d'
  outline-variant: '#c5c6cd'
  surface-tint: '#545f73'
  primary: '#091426'
  on-primary: '#ffffff'
  primary-container: '#1e293b'
  on-primary-container: '#8590a6'
  inverse-primary: '#bcc7de'
  secondary: '#505f76'
  on-secondary: '#ffffff'
  secondary-container: '#d0e1fb'
  on-secondary-container: '#54647a'
  tertiary: '#001815'
  on-tertiary: '#ffffff'
  tertiary-container: '#002f2a'
  on-tertiary-container: '#28a094'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#d8e3fb'
  primary-fixed-dim: '#bcc7de'
  on-primary-fixed: '#111c2d'
  on-primary-fixed-variant: '#3c475a'
  secondary-fixed: '#d3e4fe'
  secondary-fixed-dim: '#b7c8e1'
  on-secondary-fixed: '#0b1c30'
  on-secondary-fixed-variant: '#38485d'
  tertiary-fixed: '#89f5e7'
  tertiary-fixed-dim: '#6bd8cb'
  on-tertiary-fixed: '#00201d'
  on-tertiary-fixed-variant: '#005049'
  background: '#f7f9fb'
  on-background: '#191c1e'
  surface-variant: '#e0e3e5'
typography:
  display-lg:
    fontFamily: Source Serif 4
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 56px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Source Serif 4
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
  headline-lg-mobile:
    fontFamily: Source Serif 4
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 36px
  headline-md:
    fontFamily: Source Serif 4
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  body-lg:
    fontFamily: Source Serif 4
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Source Serif 4
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  label-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 20px
    letterSpacing: 0.01em
  label-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.05em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  unit: 8px
  container-max: 1120px
  gutter: 24px
  margin-mobile: 16px
  margin-desktop: 40px
---

## Brand & Style
The design system is engineered for a professional, contemplative, and focused Islamic learning experience. It balances traditional scholarly authority with modern functional clarity. 

The aesthetic is a hybrid of **Minimalism** and **Modern Corporate**, utilizing generous whitespace to reduce cognitive load during study. Emotional resonance is achieved through "Azure Mosaic" motifs—mathematically precise geometric patterns used sparingly as architectural accents rather than decorative clutter. The interface should feel like a quiet, sunlit library: structured, respectful, and intellectually stimulating.

## Colors
The palette is rooted in deep, scholarly tones. 
- **Primary (Deep Indigo):** Used for primary navigation, headings, and high-importance text to establish authority.
- **Secondary (Slate Blue):** Applied to supporting UI elements, icons, and secondary labels to provide a calm hierarchy.
- **Tertiary (Vibrant Teal):** Reserved for action states, progress indicators, and "Aha!" moments in the learning journey.
- **Surface & Background:** The background uses a very light slate (#f8fafc) to reduce eye strain compared to pure white, while "Silver" (#e2e8f0) is used for hairline dividers and subtle borders.

## Typography
This design system utilizes **Source Serif 4** for all editorial and long-form content. Its sturdy, professional serifs provide the necessary gravitas for sacred and academic texts. 

For functional UI elements—such as buttons, navigation labels, and metadata—**Inter** is employed. This sans-serif pairing ensures that utility remains distinct from content, maintaining a clear separation between the "vessel" (the app) and the "water" (the knowledge).

## Layout & Spacing
The layout follows a **Fixed Grid** philosophy on desktop to preserve the readability of serif text, centering the content to mimic a book layout. On mobile, it transitions to a fluid system with standard safe-area margins.

A strict 8px base unit governs all spatial relationships. Vertical rhythm is critical; double the standard spacing is often used between major sections to emphasize the "Mosaic" patterns in headers and to provide "breathing room" for reflection.

## Elevation & Depth
Depth is achieved primarily through **Tonal Layers** and **Low-Contrast Outlines** rather than aggressive shadows. 
- **Surface 0:** The base background (#f8fafc).
- **Surface 1:** Pure white cards with a subtle 1px silver border (#e2e8f0).
- **Interactive:** A soft, diffused teal-tinted shadow is applied only to the primary active element (e.g., the current lesson card) to draw focus without disrupting the calm atmosphere.
- **Mosaic Headers:** These appear on the base layer, creating a sense of "foundation" upon which the content cards sit.

## Shapes
The shape language is **Soft**. To reflect the precision of geometric mosaic art, the roundedness is kept subtle (4px - 8px). This avoids the "playfulness" of highly rounded corners while softening the "harshness" of sharp 90-degree angles. Buttons and input fields should feel like precisely cut stones in a larger pattern.

## Components
- **Buttons:** Primary buttons use the Deep Indigo background with white Source Serif text. Secondary buttons use a Silver border with Teal text.
- **Cards:** White backgrounds, 1px Silver borders, and a slight top-border accent in Teal (2px) for active states.
- **Mosaic Headers:** Functional containers that house the title of a section, overlaid on a faint, geometric pattern in Slate Blue at 5-10% opacity.
- **Lists:** Clean, separated by subtle silver hairlines. Icons should be Slate Blue.
- **Input Fields:** Minimalist with a 1px Silver bottom-border that transforms into a 2px Teal border on focus.
- **Progress Bars:** Use a Slate Blue track with a Teal fill, reflecting the "path" of learning.
- **Dividers:** Always 1px "Silver" (#e2e8f0). For section breaks, a small geometric glyph (a 4-point star or mosaic tile) can be centered on the line.