---
name: Al-Mizan Design System
colors:
  surface: '#fbf9f5'
  surface-dim: '#dbdad6'
  surface-bright: '#fbf9f5'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f5f3ef'
  surface-container: '#efeeea'
  surface-container-high: '#eae8e4'
  surface-container-highest: '#e4e2de'
  on-surface: '#1b1c1a'
  on-surface-variant: '#404944'
  inverse-surface: '#30312e'
  inverse-on-surface: '#f2f0ed'
  outline: '#707974'
  outline-variant: '#bfc9c3'
  surface-tint: '#2b6954'
  primary: '#003527'
  on-primary: '#ffffff'
  primary-container: '#064e3b'
  on-primary-container: '#80bea6'
  inverse-primary: '#95d3ba'
  secondary: '#9b4500'
  on-secondary: '#ffffff'
  secondary-container: '#fd8a42'
  on-secondary-container: '#682c00'
  tertiary: '#4a2400'
  on-tertiary: '#ffffff'
  tertiary-container: '#6a3700'
  on-tertiary-container: '#ff9939'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#b0f0d6'
  primary-fixed-dim: '#95d3ba'
  on-primary-fixed: '#002117'
  on-primary-fixed-variant: '#0b513d'
  secondary-fixed: '#ffdbca'
  secondary-fixed-dim: '#ffb68e'
  on-secondary-fixed: '#331200'
  on-secondary-fixed-variant: '#763300'
  tertiary-fixed: '#ffdcc3'
  tertiary-fixed-dim: '#ffb77d'
  on-tertiary-fixed: '#2f1500'
  on-tertiary-fixed-variant: '#6e3900'
  background: '#fbf9f5'
  on-background: '#1b1c1a'
  surface-variant: '#e4e2de'
typography:
  display-lg:
    fontFamily: Source Serif 4
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 56px
    letterSpacing: -0.02em
  display-lg-mobile:
    fontFamily: Source Serif 4
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
  headline-md:
    fontFamily: Source Serif 4
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 36px
  headline-sm:
    fontFamily: Source Serif 4
    fontSize: 22px
    fontWeight: '600'
    lineHeight: 30px
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  label-caps:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.1em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  unit: 8px
  container-max: 1140px
  gutter: 24px
  margin-mobile: 16px
  margin-desktop: 40px
---

## Brand & Style
The design system is built for a scholarly audience seeking clarity in Islamic Jurisprudence. The brand personality is **Academic, Reverent, and Timeless**. It avoids the clutter of modern social media in favor of a "Digital Manuscript" aesthetic—where the focus is on the weight of the word and the precision of the law.

The design style is **Sophisticated Minimalism with Subtle Tactility**. It draws inspiration from classical Islamic bookbinding and calligraphy, utilizing high-quality whitespace, geometric precision, and layered surfaces that feel like fine parchment. The emotional response should be one of intellectual calm and spiritual focus.

## Colors
The palette is grounded in the tradition of classical manuscripts.
- **Primary (Deep Emerald):** Used for primary navigation, headers, and signifying authority. It represents the richness of Islamic tradition.
- **Secondary (Burnished Gold):** Used sparingly for accents, icons of distinction, and interactive focus states. It mimics gold leaf illumination.
- **Neutral (Parchment):** The foundation of the UI is a warm, off-white (#FDFBF7) which reduces eye strain during long-form reading compared to pure white.
- **Semantic Colors:** Success is a soft sage, while warnings utilize a muted terracotta to maintain the earthy, organic feel of the system.

## Typography
The typographic hierarchy creates a bridge between the old and new.
- **Headlines:** Use **Source Serif 4** for its authoritative, academic weight. It echoes the structure of traditional printing while remaining legible on high-density displays.
- **Body & Interface:** Use **Plus Jakarta Sans**. Its soft, slightly rounded terminals complement the organic nature of the serif headings while providing modern clarity for dense legal text.
- **Arabic Script Integration:** When displaying Arabic text (Ayat or Hadith), use a traditional Naskh-style font, sized 125% larger than the surrounding English text to ensure the diacritics (harakat) are clearly visible.

## Layout & Spacing
The layout follows a **Fixed Grid** philosophy on desktop to mimic the centered, focused margins of a physical book. 

- **The Golden Ratio:** Use a 1.618 ratio to determine the relationship between content areas and sidebars.
- **Gutter & Rhythm:** A strict 8px base unit is used. Body text should be constrained to a maximum width of 720px (approx. 70-80 characters) to maintain scholarly readability.
- **Responsive Behavior:** On mobile, margins tighten to 16px, and complex multi-column jurisprudence tables reflow into vertical cards with clear hierarchical dividers.

## Elevation & Depth
This design system avoids heavy drop shadows. Depth is communicated through **Tonal Layering and Fine Outlines**:
- **Level 0 (Base):** The Parchment background.
- **Level 1 (Cards):** A slightly lighter tint than the base, defined by a 1px border in a muted gold-tan (#E5E0D5).
- **Overlays:** Use a subtle "Soft Focus" backdrop blur (8px) for modals to keep the user grounded in their previous context.
- **Geometric Overlays:** Use SVG patterns of 8-point stars (Khatim) at 3% opacity as background watermarks for high-level section headers to add texture without distracting from the text.

## Shapes
The shape language is **Soft but Structured**. 
- **Corner Radii:** Use the `Soft` (0.25rem) setting for most containers to maintain a sense of precision. 
- **Decorative Framing:** Use "Inverted Corner" masks (notched corners) for featured image containers or primary action cards to evoke the geometry of Islamic arches (Mihrab).
- **Interactive Elements:** Buttons should have a slightly higher roundedness than containers to signify touchability, but never fully pill-shaped.

## Components
- **Buttons:** Primary buttons use the Deep Emerald background with Gold text. High-emphasis actions should feature a subtle 1px inset border in Gold.
- **Study Chips:** Use for categorizing schools of thought (Madhaahib). These should be outlined with a 1px border and use `label-caps` typography.
- **The "Dars" Card:** Lesson cards should feature a vertical border on the left (or right for RTL) using the Secondary Gold color to indicate progress or importance.
- **Input Fields:** Minimalist design with only a bottom border that transitions from Muted Tan to Deep Emerald on focus. No heavy boxes.
- **Dividers:** Use custom SVG dividers featuring a centered geometric knot instead of simple lines to separate major chapters or sections of law.
- **Hadith/Quotation Blocks:** Indented with a subtle background tint and a stylized quotation mark or 'Qala' (He said) icon in the margin.