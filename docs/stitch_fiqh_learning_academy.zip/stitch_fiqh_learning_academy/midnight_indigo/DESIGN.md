---
name: Midnight Indigo
colors:
  surface: '#0b1326'
  surface-dim: '#0b1326'
  surface-bright: '#31394d'
  surface-container-lowest: '#060e20'
  surface-container-low: '#131b2e'
  surface-container: '#171f33'
  surface-container-high: '#222a3d'
  surface-container-highest: '#2d3449'
  on-surface: '#dae2fd'
  on-surface-variant: '#bacac5'
  inverse-surface: '#dae2fd'
  inverse-on-surface: '#283044'
  outline: '#859490'
  outline-variant: '#3c4a46'
  surface-tint: '#3cddc7'
  primary: '#57f1db'
  on-primary: '#003731'
  primary-container: '#2dd4bf'
  on-primary-container: '#00574d'
  inverse-primary: '#006b5f'
  secondary: '#b7c8e1'
  on-secondary: '#213145'
  secondary-container: '#3a4a5f'
  on-secondary-container: '#a9bad3'
  tertiary: '#ffd1aa'
  on-tertiary: '#4b2800'
  tertiary-container: '#ffac5a'
  on-tertiary-container: '#744000'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#62fae3'
  primary-fixed-dim: '#3cddc7'
  on-primary-fixed: '#00201c'
  on-primary-fixed-variant: '#005047'
  secondary-fixed: '#d3e4fe'
  secondary-fixed-dim: '#b7c8e1'
  on-secondary-fixed: '#0b1c30'
  on-secondary-fixed-variant: '#38485d'
  tertiary-fixed: '#ffdcc0'
  tertiary-fixed-dim: '#ffb875'
  on-tertiary-fixed: '#2d1600'
  on-tertiary-fixed-variant: '#6b3b00'
  background: '#0b1326'
  on-background: '#dae2fd'
  surface-variant: '#2d3449'
typography:
  display-lg:
    fontFamily: Source Serif 4
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 56px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Source Serif 4
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
  headline-lg-mobile:
    fontFamily: Source Serif 4
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  title-md:
    fontFamily: Source Serif 4
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 30px
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  label-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 20px
    letterSpacing: 0.01em
  label-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.04em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  base: 4px
  xs: 8px
  sm: 16px
  md: 24px
  lg: 40px
  xl: 64px
  gutter: 16px
  margin-mobile: 20px
  margin-desktop: auto
  max-width-content: 720px
---

## Brand & Style
The design system is engineered for deep focus and contemplative study. The brand personality is scholarly, nocturnal, and serene, catering to students and researchers of Fiqh who engage with complex texts during late-night or early-morning hours. 

The aesthetic blends **Minimalism** with **Tonal Layering**, utilizing a dark, low-fatigue color palette to reduce eye strain. The UI evokes an emotional response of "Quiet Authority"—it is respectful of the sacred nature of the content while remaining highly functional and technically precise. Every element is designed to fade into the background, leaving the text as the primary focus.

## Colors
The palette is dominated by deep, cooling tones to maintain a calm environment. 
- **Primary Accent:** Soft Teal (#2dd4bf) is used sparingly for active states, primary actions, and highlighting critical markers in the text.
- **Surface Strategy:** The background uses a rich Midnight Blue (#0f172a). Containers and cards utilize Slate (#1e293b) to create subtle separation without harsh contrast.
- **Typography Colors:** High-readability off-whites (#f1f5f9) are used for body text to prevent the "vibrating" effect of pure white on dark backgrounds. Secondary metadata uses muted slates to establish hierarchy.

## Typography
The typography system prioritizes the distinction between "Content" (the sacred/scholarly text) and "Interface" (the navigation and tools).

- **Scholarly Text:** All headings and primary reading passages use **Source Serif 4**. This provides a traditional, authoritative feel that mimics physical manuscripts. The generous line height (1.6x for body-lg) ensures readability during long study sessions.
- **System Interface:** **Inter** is utilized for all functional elements, labels, and inputs. Its geometric clarity provides a sharp contrast to the serif headings, making the app feel like a modern research tool.
- **Arabic Text Integration:** When displaying Arabic script, it should be rendered 125% larger than the surrounding English Inter text to maintain visual parity in optical weight.

## Layout & Spacing
This design system employs a **Fixed Content Grid** for reading and a **Fluid UI Grid** for navigation.

- **Reading View:** Centered single-column layout with a maximum width of 720px. This mimics the "focus mode" of modern writing apps, preventing long line lengths that tire the eye.
- **Desktop/Tablet:** A 12-column grid with a wide 40px gutter to provide significant "breathable" white space (or "dark space").
- **Mobile:** A 4-column grid with 20px side margins. 
- **Rhythm:** Spacing follows a 4px baseline, with 24px (md) being the standard padding for containers and section grouping.

## Elevation & Depth
In the "Midnight Indigo" environment, depth is communicated through **Tonal Layers** rather than shadows. 

1. **Level 0 (Background):** #0f172a - The base canvas.
2. **Level 1 (Containers/Cards):** #1e293b - Subtle elevation for grouped content.
3. **Level 2 (Popovers/Modals):** #334155 - Brighter slate to indicate the element is closest to the user.

Shadows, when used (only on Level 2), must be ultra-diffused: `0 20px 25px -5px rgba(0, 0, 0, 0.5)`. Borders are avoided unless they are "Ghost Outlines" using 10% opacity Teal to highlight a focused input.

## Shapes
The shape language is **Soft (0.25rem / 4px)**. This subtle rounding suggests precision and intellectual rigor, avoiding the overly "bubbly" feel of high-roundedness systems while remaining more approachable than sharp 90-degree corners. 

Buttons and input fields use the standard `rounded` (4px), while large content blocks like lesson cards may use `rounded-lg` (8px) to soften the overall interface.

## Components
- **Buttons:** Primary buttons use a solid Soft Teal background with Midnight Blue text for maximum legibility. Secondary buttons are outlined in Slate with Teal text.
- **Source Cards:** Used for Fiqh citations. These have a Level 1 background, a 2px left-accent border in Teal, and use Source Serif 4 for the content.
- **Chips/Tags:** Small, pill-shaped markers for categories (e.g., "Maliki", "Hanafi"). These use a semi-transparent Teal background (15% opacity) with Teal text.
- **Input Fields:** Darker than the container they sit in, with a subtle 1px border. The cursor and focus ring must be the Primary Teal.
- **Progress Indicators:** Thin, 2px lines at the top of the screen or chapter, using a Teal gradient to represent the journey through a text.
- **Navigation:** Bottom navigation (mobile) or side rail (tablet) uses a blurred backdrop (Glassmorphism) of the background color to maintain the "nocturnal" depth.